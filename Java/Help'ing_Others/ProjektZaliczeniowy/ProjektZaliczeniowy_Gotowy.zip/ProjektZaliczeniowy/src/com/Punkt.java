package com;

/**
 * Klasa pozwalająca zebrać 2 współrzędne w jeden punkt, Wrzucamy 2 współrzędne otrzymujemy klasę Punkt (x,y)
 */
public class Punkt {


    int x;
    int y;

    public Punkt(int x, int y) {
        this.x = x;
        this.y = y;
    }


}
