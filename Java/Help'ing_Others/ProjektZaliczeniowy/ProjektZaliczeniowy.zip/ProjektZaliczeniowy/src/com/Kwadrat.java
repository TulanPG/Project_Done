package com;

public class Kwadrat extends Prostokat implements Obliczenia{




    public Kwadrat(Punkt A, Punkt B, Punkt C, Punkt D) {
        super(A, B, C, D);

        pole = poleProstokat(max,max);
    }

    @Override
    public String toString() {
        return "Kwadrat{" +
                "pole=" + pole +
                ", obwod=" + obwod +
                '}';
    }
}
