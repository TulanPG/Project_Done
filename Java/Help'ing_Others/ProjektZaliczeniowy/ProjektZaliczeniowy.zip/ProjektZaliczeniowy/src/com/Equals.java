package com;

public class Equals {

    boolean rowny;

    public Equals(Figura a, Figura b) {

        ;

    }

    @Override
    public String toString() {
        return "Equals{" +
                "rowny=" + rowny +
                '}';
    }

    public void czyRówny(Figura a, Figura b){
//Sprawdzić poprzez długości boków, ilości boków, pola i obwodu

    if (a.equals(b)){
        rowny = true;
    }

    else {
        rowny = false;
    }
}



}
