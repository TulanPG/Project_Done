package com;

import java.awt.*;
import java.util.ArrayList;
import java.util.Arrays;

public class Main {


    public static void main(String[] args) {

        List<Figury> figury = new ArrayList<>();

        Punkt A = new Punkt(1, 2);
        Punkt B = new Punkt(1, 3);
        Punkt C = new Punkt(2, 4);
        Punkt D = new Punkt(3, 4);
        Punkt E = new Punkt(5, 4);

        Figura a = new Trojkat(A, B, C);
        Figura b = new Kolo(A, B);
        Figura c = new Prostokat(A, B,C,D);

        Figura d = new Kwadrat(A, B,C,E);
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);

        array.add();



        System.out.println(new Equals(a,a));




    }

    class Figury {

        private double a, b, c, d, pole, obwod;

        public Figury(double a, double b, double c, double d, double pole, double obwod){

            this.a = a;
            this.b = b;
            this.c = c;
            this.d = d;
            this.pole = pole;
            this.obwod = obwod;
        }

        public double getA() {
            return a;
        }

        public void setA(double a) {
            this.a = a;
        }

        public double getB() {
            return b;
        }

        public void setB(double b) {
            this.b = b;
        }

        public double getC() {
            return c;
        }

        public void setC(double c) {
            this.c = c;
        }

        public double getD() {
            return d;
        }

        public void setD(double d) {
            this.d = d;
        }

        public double getPole() {
            return pole;
        }

        public void setPole(double pole) {
            this.pole = pole;
        }

        public double getObwod() {
            return obwod;
        }

        public void setObwod(double obwod) {
            this.obwod = obwod;
        }
    }


    class Punkty {
        private int punktA, punktB, punktC,punktD;


        public Punkty(int punktA, int punktB, int punktC, int punktD) {
            this.punktA = punktA;
            this.punktB = punktB;
            this.punktC = punktC;
            this.punktD = punktD;

        }

        public int getPunktA() {
            return punktA;
        }

        public void setPunktA(int punktA) {
            this.punktA = punktA;
        }

        public int getPunktB() {
            return punktB;
        }

        public void setPunktB(int punktB) {
            this.punktB = punktB;
        }

        public int getPunktC() {
            return punktC;
        }

        public void setPunktC(int punktC) {
            this.punktC = punktC;
        }

        public int getPunktD() {
            return punktD;
        }

        public void setPunktD(int punktD) {
            this.punktD = punktD;
        }


    }




}
