package com;

public class Linia extends Figura implements Obliczenia{

    double a, b, c,d, min, max;

    public double getA() {
        return a;
    }

    public double getB() {
        return b;
    }

    public double getC() {
        return c;
    }

    public double getD() {
        return d;
    }

    public double getMin() {
        return min;
    }

    public double getMax() {
        return max;
    }

    public Linia(Punkt A, Punkt B) {
        super(A, B);

        a = linia(A,B);

    }

    public Linia(Punkt A, Punkt B, Punkt C) {
        super(A, B, C);
        a = linia(A,B);
        b = linia(B,C);
        c = linia(C,A);
    }

    public Linia(Punkt A, Punkt B, Punkt C, Punkt D) {
        super(A, B, C, D);

        max = max(linia(A,B),linia(B,C), linia(C,D), linia(D,A));
        min = min(linia(A,B),linia(B,C), linia(C,D), linia(D,A));

        a= linia(A,B);
        b = linia(B,C);
        c = linia(C,D);
        d = linia(D,A);



    }

    public static double max(double a, double b, double c, double d) {

        double max = a;

        if (b > max)
            max = b;
        if (c > max)
            max = c;
        if (d > max)
            max = d;

        return max;
    }
    public static double min(double a, double b, double c, double d) {

        double min = a;

        if (b < min)
            min = b;
        if (c < min)
            min = c;
        if (d < min)
            min = d;

        return min;
    }

    @Override
    public double linia(Punkt A, Punkt B) {
        double pomocnicza1,pomocnicza2;

        pomocnicza1 = Math.pow((B.x - A.x),2);
        pomocnicza2 = Math.pow((B.y - A.y),2);
        double DlugoscLinii = Math.sqrt(pomocnicza1+pomocnicza2);

        return DlugoscLinii;
    }

    @Override
    public double poleTrojkat(Punkt A, Punkt B, Punkt C) {
        return 0;
    }

    @Override
    public double poleKolo(double a) {
        return 0;
    }

    @Override
    public double poleProstokat(double max, double min) {
        return 0;
    }

    @Override
    public double obwod(double  a, double  b, double  c, double  d) {
        return 0;
    }

    @Override
    public double obwodKolo(double a) {
        return 0;
    }


}
