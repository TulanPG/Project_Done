package com;

public class Prostokat extends Figura implements Obliczenia{

    double pole, obwod, min, max;


    public double getPole() {
        return pole;
    }

    public void setPole(double pole) {
        this.pole = pole;
    }

    public double getObwod() {
        return obwod;
    }

    public void setObwod(double obwod) {
        this.obwod = obwod;
    }

    public Prostokat(Punkt A, Punkt B, Punkt C, Punkt D) {
        super(A, B, C, D);


        Figura pomocniczy = new Linia(A,B,C,D);
        double a =((Linia) pomocniczy).getA();
        double b =((Linia) pomocniczy).getB();
        double c =((Linia) pomocniczy).getC();
        double d = ((Linia) pomocniczy).getD();
        min =((Linia) pomocniczy).getMin();
        max =((Linia) pomocniczy).getMax();

        setObwod(obwod(a,b,c,d));
        setPole(poleProstokat(min,max));
    }


    @Override
    public String toString() {
        return "Prostokat{" +
                "pole=" + pole +
                ", obwod=" + obwod +
                '}';
    }

    @Override
    public double linia(Punkt A, Punkt B) {
        return 0;
    }

    @Override
    public double poleTrojkat(Punkt A, Punkt B, Punkt C) {
        return 0;
    }

    @Override
    public double poleKolo(double a) {
        return 0;
    }

    @Override
    public double poleProstokat(double max, double min) {

        double pole;
        pole = max*min;


        return pole;
    }

    @Override
    public double obwod(double a, double b, double c, double d) {

        double obwod = a+b+c+d;
        return obwod;

    }

    @Override
    public double obwodKolo(double a) {
        return 0;
    }
}
