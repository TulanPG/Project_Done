package com;


public class Trojkat extends Figura implements Obliczenia{
    double pole, obwod;



    public Trojkat(Punkt A, Punkt B, Punkt C) {
        super(A, B, C);
        Figura pomocniczy = new Linia(A,B,C);
        double a =((Linia) pomocniczy).getA();
        double b =((Linia) pomocniczy).getB();
        double c =((Linia) pomocniczy).getC();
        double d = 0;
        setObwod(obwod(a,b,c,d));
        setPole(poleTrojkat(A,B,C));
    }


    @Override
    public String toString() {
        return "Trojkat{" +
                "pole=" + pole +
                ", obwod=" + obwod +
                '}';
    }

    public void setPole(double pole) {
        this.pole = pole;
    }

    public double getPole() {
        return pole;
    }

    public double getObwod() {
        return obwod;
    }

    public void setObwod(double obwod) {
        this.obwod = obwod;
    }




    @Override
    public double linia(Punkt A, Punkt B) {
        return 0;
    }

    @Override
    public double poleTrojkat(Punkt A, Punkt B, Punkt C) {
        double area = (A.x * (B.y - C.y) + B.x * (C.y - A.y) + C.x * (A.y - B.y)) / 2.0;
        return Math.abs(area);
    }

    @Override
    public double poleKolo(double a) {
        return 0;
    }

    @Override
    public double poleProstokat(double max, double min) {
        return 0;
    }

    @Override
    public double obwod(double  a, double  b, double  c, double  d) {
        double obwod = a+b+c+d;
        return obwod;
    }

    @Override
    public double obwodKolo(double a) {
        return 0;
    }


}
