package com;

public class Kolo extends Figura implements Obliczenia{

    final static double pi = 3.1416;
    double pole, obwod;




    public Kolo(Punkt A, Punkt B) {
        super(A, B);
        Figura pomocniczy = new Linia(A,B);
        double a =((Linia) pomocniczy).getA();

        setPole(poleKolo(a));
        setObwod(obwodKolo(a));
    }

    @Override
    public String toString() {
        return "Kolo{" +
                "pole=" + pole +
                ", obwod=" + obwod +
                '}';
    }

    @Override
    public double linia(Punkt A, Punkt B) {
        return 0;
    }

    @Override
    public double poleTrojkat(Punkt A, Punkt B, Punkt C) {
        return 0;
    }

    @Override
    public double poleKolo(double a) {
        double pole;
        pole = pi*a*a;

        return pole;
    }

    @Override
    public double poleProstokat(double max, double min) {
        return 0;
    }

    @Override
    public double obwod(double a, double b, double c, double d) {
        return 0;
    }

    @Override
    public double obwodKolo(double a) {
        double obwodKola;
        obwodKola = pi * a * 2;
        return obwodKola;
    }

    public double getPole() {
        return pole;
    }

    public void setPole(double pole) {
        this.pole = pole;
    }

    public double getObwod() {
        return obwod;
    }

    public void setObwod(double obwod) {
        this.obwod = obwod;
    }
}
