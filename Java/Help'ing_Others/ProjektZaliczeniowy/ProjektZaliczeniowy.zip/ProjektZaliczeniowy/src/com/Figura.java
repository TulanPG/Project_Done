package com;

public abstract class Figura {


    public Figura(Punkt A) {


    }

    public Figura(Punkt A, Punkt B) {


    }

    public Figura(Punkt A, Punkt B, Punkt C) {


    }

    public Figura(Punkt A, Punkt B, Punkt C, Punkt D) {


    }
}


