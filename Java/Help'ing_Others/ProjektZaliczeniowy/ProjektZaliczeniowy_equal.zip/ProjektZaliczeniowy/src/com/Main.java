package com;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {


    public static void main(String[] args) {
        List<Figury> figury = new ArrayList<>();
        Equals figura = new Equals();
        Scanner in = new Scanner(System.in);


        /*Punkt A = new Punkt(1, 2);
        Punkt B = new Punkt(1, 3);
        Punkt C = new Punkt(2, 4);
        Punkt D = new Punkt(3, 4);
        Punkt E = new Punkt(5, 4);
        Punkt Z = null;*/

        System.out.println("Wprowadz ilość figur: ");
        int ilosc = in.nextInt();

        for(int i = 0; i<ilosc; i++) {
            Punkt A = null,B=null,C=null,D=null,Z=null;

            System.out.println("Wprowadz ilość punktów figury "+i+": ");
            int iloscPunktow = in.nextInt();

            for(int j = 0; j<iloscPunktow; j++) {

                System.out.println("Wprowadz punkt " + j + ": \nx: ");
                int x = in.nextInt();
                System.out.println("Wprowadz punkt " + j + ": \ny: ");
                int y = in.nextInt();

                if(j==0) {
                    A = new Punkt(x, y);
                }
                if(j==1) {
                    B = new Punkt(x, y);
                }
                if(j==2) {
                    C = new Punkt(x, y);
                }
                if(j==3) {
                    D = new Punkt(x, y);
                }
            }
            figury.add(
                    figura.ObliczeniaFigur(A,B,C,D));
        }
        System.out.println(figury);

        System.out.println("Ile porównań chcesz wprowadzić: ");
        int ilosc2 = in.nextInt();
        for(int i = 0; i<ilosc2; i++) {

            System.out.println("Którą figurę chcesz porównać?\n wpisz pierwszą(kolejność wprowadzania): ");
            int figura1 = in.nextInt();
            System.out.println("Którą figurę chcesz porównać?\n wpisz druga(kolejność wprowadzania): ");
            int figura2 = in.nextInt();

            System.out.println("Figury są równe?: "+
                    figura.Equals(figury.get(figura1),figury.get(figura2)));
        }


        /*
       Metoda krok po kroku na otrzymywanie wyników

        Figura a = new Trojkat(A, B, C);
        Figura b = new Kolo(A, B);
        Figura c = new Prostokat(A, B,C,D);
        Figura d = new Kwadrat(A, B,C,E);
        System.out.println(a);
        System.out.println(b);
        System.out.println(c);
        System.out.println(d);


        */
    }

}
