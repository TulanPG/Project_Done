package com;

import java.util.ArrayList;
import java.util.List;

public class Equals {

public boolean rowne = false;

    /**
     *
     * @param a  Dostarczona figura w klasie "Figury" tj. boki, pole, obwód,
     * @param b  Dostarczona figura w klasie "Figury" tj. boki, pole, obwód,
     * @return Równe czy nie równe (Prawda/fałsz)
     */

    public boolean Equals(Figury a, Figury b){
        rowne = false;
        if (a.equals(b)){
            rowne = true;
        }
        return rowne;
    }

    /**
     * Oblicza odpowiednie figury w zależności od ilosci dostarczonych punktów, samemu dobiera co to za figura na podstawie punktów
     * @return "Figury" - Boki, pole, obwód w klasie
     */
    public Figury ObliczeniaFigur(Punkt A, Punkt B, Punkt C, Punkt D){
        Figury figuraA = new Figury();


        if (C == null && D == null) {
            Kolo aa = new Kolo(A,B);
            figuraA = new Figury(aa.bokA, aa.bokB, aa.bokC, aa.bokD, aa.pole, aa.obwod);
        }

        if (C != null && D == null) {

            Trojkat aa = new Trojkat(A, B, C);
            figuraA = new Figury(aa.bokA, aa.bokB, aa.bokC, aa.bokD, aa.pole, aa.obwod);
        }
        if (C != null && D != null){
            Prostokat aa = new Prostokat(A, B, C, D);
            figuraA = new Figury(aa.bokA, aa.bokB, aa.bokC, aa.bokD, aa.pole, aa.obwod);
        }


        return figuraA;
    }


}
