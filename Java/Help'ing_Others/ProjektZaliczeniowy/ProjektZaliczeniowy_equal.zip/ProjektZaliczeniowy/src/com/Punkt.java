package com;

public class Punkt {


    int x;
    int y;

    public Punkt(int x, int y) {
        this.x = x;
        this.y = y;
    }


}
